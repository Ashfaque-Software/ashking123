function generateNumber() {
  // generate a random integer(hint : Math.random)
}

function checkOddEven(num) {
  // logic for even / odd
}

window.onload = function () {
  // add event listeners to the button here
};

// donot change the following export statement

if (typeof exports !== "undefined") {
  module.exports = {
    generateNumber,
    checkOddEven,
  };
}
